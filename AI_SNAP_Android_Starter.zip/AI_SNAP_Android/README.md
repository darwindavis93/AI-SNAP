# AI SNAP Android starter

A starter Android camera app for Pixel devices. This refreshed minimal build provides a live CameraX preview and saves a captured photo to `Pictures/AI SNAP`.

## Build
Open this folder in Android Studio and build the `app` debug variant, or use the GitHub Actions workflow added in the repository.

## Important
This is an early prototype, not the full semi-automatic AI photo-selection product yet. It currently provides camera preview and single-photo capture. Test on-device before broader distribution.

package com.aisnap.app

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.GridLayout
import android.widget.ScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var photoButton: Button
    private lateinit var burstButton: Button
    private var imageCapture: ImageCapture? = null
    private val worker: ExecutorService = Executors.newSingleThreadExecutor()
    private val burstFiles = mutableListOf<File>()
    private var burstIndex = 0
    private val burstCount = 5
    private var busy = false

    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) startCamera() else Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            permission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 20)
            setBackgroundColor(0xFF090D18.toInt())
        }
        val title = TextView(this).apply {
            text = "AI SNAP"
            textSize = 30f
            letterSpacing = 0.08f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        val subtitle = TextView(this).apply {
            text = "SMART CAMERA  •  BEST-MOMENT ASSISTANT"
            textSize = 11f
            letterSpacing = 0.08f
            setTextColor(0xFF62E6D5.toInt())
            setPadding(0, 4, 0, 16)
        }
        previewView = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }
        statusText = TextView(this).apply {
            text = "Camera ready. Choose a capture mode."
            textSize = 14f
            setTextColor(0xFFD5D9E6.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 14, 8, 14)
        }
        photoButton = Button(this).apply {
            text = "CAPTURE PHOTO"
            setOnClickListener { takeSinglePhoto() }
        }
        burstButton = Button(this).apply {
            text = "SMART BURST  •  5 PHOTOS"
            setOnClickListener { startBurst() }
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(previewView, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(statusText)
        root.addView(photoButton)
        root.addView(burstButton)
        setContentView(root)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            imageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .build()
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
                statusText.text = "Ready • Photo or 5-shot Smart Burst"
            } catch (e: Exception) {
                statusText.text = "Camera could not start"
                Toast.makeText(this, "Unable to start camera: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun setBusy(value: Boolean, message: String) {
        busy = value
        photoButton.isEnabled = !value
        burstButton.isEnabled = !value
        statusText.text = message
    }

    private fun timestamp(): String =
        SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date())

    private fun takeSinglePhoto() {
        val capture = imageCapture ?: return
        if (busy) return
        val name = "AI_SNAP_${timestamp()}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI SNAP")
        }
        val options = ImageCapture.OutputFileOptions.Builder(
            contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ).build()
        setBusy(true, "Capturing photo…")
        capture.takePicture(options, ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    setBusy(false, "Photo saved • Ready for your next shot")
                    Toast.makeText(this@MainActivity, "Saved to Pictures/AI SNAP", Toast.LENGTH_LONG).show()
                }
                override fun onError(exc: ImageCaptureException) {
                    setBusy(false, "Capture failed. Please try again.")
                    Toast.makeText(this@MainActivity, exc.message ?: "Capture failed", Toast.LENGTH_LONG).show()
                }
            })
    }

    private fun startBurst() {
        if (busy || imageCapture == null) return
        burstFiles.clear()
        burstIndex = 0
        setBusy(true, "Smart Burst starting…")
        captureNextBurstFrame()
    }

    private fun captureNextBurstFrame() {
        val capture = imageCapture
        if (capture == null) {
            finishBurstWithError("Camera is unavailable")
            return
        }
        if (burstIndex >= burstCount) {
            statusText.text = "Analysing ${burstFiles.size} photos…"
            analyseBurst()
            return
        }
        val file = File(cacheDir, "aisnap_burst_${timestamp()}.jpg")
        val options = ImageCapture.OutputFileOptions.Builder(file).build()
        statusText.text = "Smart Burst • ${burstIndex + 1} of $burstCount"
        capture.takePicture(options, ContextCompat.getMainExecutor(this),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    burstFiles.add(file)
                    burstIndex++
                    captureNextBurstFrame()
                }
                override fun onError(exc: ImageCaptureException) {
                    captureNextBurstFrame()
                }
            })
    }

    private data class ShotScore(val file: File, val score: Double, val note: String)

    private fun analyseBurst() {
        if (burstFiles.isEmpty()) {
            finishBurstWithError("No photos were captured. Please try again.")
            return
        }
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .build()
        val detector = FaceDetection.getClient(options)
        val results = mutableListOf<ShotScore>()
        var index = 0

        fun analyseNext() {
            if (index >= burstFiles.size) {
                detector.close()
                val ranked = results.sortedByDescending { it.score }
                runOnUiThread { showBurstResults(ranked) }
                return
            }
            val file = burstFiles[index++]
            try {
                val input = InputImage.fromFilePath(this, android.net.Uri.fromFile(file))
                detector.process(input)
                    .addOnSuccessListener { faces ->
                        val sharpness = estimateSharpness(file)
                        val faceScore = scoreFaces(faces)
                        val total = (faceScore * 0.75) + (sharpness * 0.25)
                        val note = when {
                            faces.isEmpty() -> "No face detected"
                            faces.any { (it.leftEyeOpenProbability ?: 0f) > 0.65f &&
                                        (it.rightEyeOpenProbability ?: 0f) > 0.65f } -> "Eyes open • face detected"
                            else -> "Face detected • check expression"
                        }
                        results.add(ShotScore(file, total, note))
                        analyseNext()
                    }
                    .addOnFailureListener {
                        results.add(ShotScore(file, estimateSharpness(file) * 0.25, "Basic image check"))
                        analyseNext()
                    }
            } catch (_: Exception) {
                results.add(ShotScore(file, 0.0, "Could not analyse"))
                analyseNext()
            }
        }
        analyseNext()
    }

    private fun scoreFaces(faces: List<Face>): Double {
        if (faces.isEmpty()) return 0.0
        val best = faces.maxOf { face ->
            val area = face.boundingBox.width().toDouble() * face.boundingBox.height()
            val eye = ((face.leftEyeOpenProbability ?: 0.5f) +
                       (face.rightEyeOpenProbability ?: 0.5f)) / 2.0
            val smile = face.smilingProbability ?: 0.5f
            val sizeScore = (area / (previewView.width.coerceAtLeast(1) *
                                     previewView.height.coerceAtLeast(1)).toDouble()).coerceIn(0.0, 1.0)
            (eye * 65.0) + (smile * 10.0) + (sizeScore * 25.0)
        }
        return best
    }

    private fun estimateSharpness(file: File): Double {
        val bitmap = BitmapFactory.decodeFile(file.absolutePath) ?: return 0.0
        val sampleW = 96
        val sampleH = max(1, (bitmap.height.toDouble() * sampleW / bitmap.width).toInt())
        val small = android.graphics.Bitmap.createScaledBitmap(bitmap, sampleW, sampleH, true)
        val pixels = IntArray(sampleW * sampleH)
        small.getPixels(pixels, 0, sampleW, 0, 0, sampleW, sampleH)
        var total = 0.0
        var count = 0
        for (y in 1 until sampleH - 1) {
            for (x in 1 until sampleW - 1) {
                fun lum(i: Int): Double {
                    val c = pixels[i]
                    return 0.299 * ((c shr 16) and 255) +
                           0.587 * ((c shr 8) and 255) +
                           0.114 * (c and 255)
                }
                val i = y * sampleW + x
                val center = lum(i)
                val lap = abs(4 * center - lum(i - 1) - lum(i + 1) -
                              lum(i - sampleW) - lum(i + sampleW))
                total += lap
                count++
            }
        }
        if (small !== bitmap) small.recycle()
        bitmap.recycle()
        return ((if (count > 0) total / count else 0.0) / 40.0).coerceIn(0.0, 1.0) * 100.0
    }

    private fun showBurstResults(ranked: List<ShotScore>) {
        if (ranked.isEmpty()) {
            finishBurstWithError("We couldn't score these photos.")
            return
        }
        val top = ranked.take(3)
        val gallery = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        val intro = TextView(this).apply {
            text = "All ${ranked.size} burst photos • Tap any photo to view it larger"
            textSize = 14f
            setTextColor(0xFFD5D9E6.toInt())
            setPadding(0, 0, 0, dp(12))
        }
        gallery.addView(intro)

        val grid = GridLayout(this).apply {
            columnCount = 2
            useDefaultMargins = true
        }
        ranked.forEachIndexed { index, shot ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(6), dp(6), dp(6), dp(10))
                setBackgroundColor(0xFF182235.toInt())
                isClickable = true
                isFocusable = true
            }
            val thumb = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(-1, dp(150))
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(loadPreviewBitmap(shot.file, 500))
                contentDescription = "Burst photo ${index + 1}"
            }
            val label = TextView(this).apply {
                text = "PHOTO ${index + 1}  •  ${shot.score.toInt()}/100\n${shot.note}"
                textSize = 12f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(dp(4), dp(7), dp(4), 0)
            }
            tile.addView(thumb)
            tile.addView(label)
            tile.setOnClickListener { showFullScreenShot(ranked, index) }
            val params = GridLayout.LayoutParams().apply {
                width = 0
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            grid.addView(tile, params)
        }
        val scroll = ScrollView(this).apply {
            addView(gallery)
        }
        gallery.addView(grid)

        val lines = ranked.mapIndexed { i, shot ->
            "${i + 1}. ${shot.note} • ${shot.score.toInt()}/100"
        }.joinToString("\n")
        val dialog = AlertDialog.Builder(this)
            .setTitle("AI SNAP • Burst gallery")
            .setView(scroll)
            .setNegativeButton("CLOSE", null)
            .setPositiveButton("SAVE TOP ${top.size}", null)
            .setOnCancelListener { finishBurstCleanup() }
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val saved = top.count { saveBestShot(it.file) }
                Toast.makeText(this, "$saved best shots saved to Pictures/AI SNAP/Best Shots", Toast.LENGTH_LONG).show()
                dialog.dismiss()
                finishBurstCleanup()
            }
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                dialog.dismiss()
                finishBurstCleanup()
            }
        }
        dialog.show()
        statusText.text = "Gallery ready • ${ranked.size} photos ranked"
        busy = false
        photoButton.isEnabled = true
        burstButton.isEnabled = true
    }

    private fun showFullScreenShot(ranked: List<ShotScore>, startIndex: Int) {
        var current = startIndex
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setBackgroundColor(0xFF090D18.toInt())
        }
        val image = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(420))
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        val caption = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, dp(8), 0, dp(8))
        }
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val previous = Button(this).apply { text = "‹ PREVIOUS" }
        val next = Button(this).apply { text = "NEXT ›" }
        controls.addView(previous, LinearLayout.LayoutParams(0, -2, 1f))
        controls.addView(next, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(image)
        content.addView(caption)
        content.addView(controls)

        fun render() {
            val shot = ranked[current]
            image.setImageBitmap(loadPreviewBitmap(shot.file, 1600))
            caption.text = "PHOTO ${current + 1} OF ${ranked.size}  •  ${shot.score.toInt()}/100\n${shot.note}"
            previous.isEnabled = current > 0
            next.isEnabled = current < ranked.lastIndex
        }
        previous.setOnClickListener {
            if (current > 0) {
                current--
                render()
            }
        }
        next.setOnClickListener {
            if (current < ranked.lastIndex) {
                current++
                render()
            }
        }
        render()
        AlertDialog.Builder(this)
            .setTitle("BURST PHOTO VIEWER")
            .setView(content)
            .setPositiveButton("DONE", null)
            .show()
    }

    private fun loadPreviewBitmap(file: File, maxDimension: Int): android.graphics.Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            var sample = 1
            while (bounds.outWidth / sample > maxDimension * 2 ||
                bounds.outHeight / sample > maxDimension * 2) {
                sample *= 2
            }
            val options = BitmapFactory.Options().apply { inSampleSize = sample }
            BitmapFactory.decodeFile(file.absolutePath, options)
        } catch (_: Exception) {
            null
        }
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    private fun saveBestShot(file: File): Boolean {
        return try {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "AI_SNAP_BEST_${timestamp()}.jpg")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AI SNAP/Best Shots")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
            contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                ?: return false
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun finishBurstCleanup() {
        burstFiles.forEach { it.delete() }
        burstFiles.clear()
        statusText.text = "Ready • Your next great shot is one tap away"
    }

    private fun finishBurstWithError(message: String) {
        setBusy(false, message)
        finishBurstCleanup()
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        worker.shutdown()
        super.onDestroy()
    }
}

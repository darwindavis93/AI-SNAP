# AI SNAP V2

Android camera prototype with:
- CameraX live preview and single-photo capture
- Five-frame Smart Burst capture
- On-device ML Kit face detection/classification
- Basic sharpness estimate and ranked burst review
- Optional saving of the top three shots to Pictures/AI SNAP/Best Shots

## Build
Open the project in Android Studio and run `assembleDebug`, or use the repository's GitHub Actions workflow.

The ranking is a first-pass heuristic, not a guarantee of the objectively best photo. It uses detected face size, eye-open probability, smile probability and a lightweight sharpness estimate. All analysis runs on-device.
